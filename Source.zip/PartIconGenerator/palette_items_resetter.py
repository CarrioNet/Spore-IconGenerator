# Reset all .prop files in creature_editor_palette_pages~, creature_editor_palette_items~ and updating the appropriate file in creature_editor_palette~ with 
# said pages allowing for easier copying and pasting, you can change the value of 'b' depending on how many pages you want.

# If you need to change the parameters for the height and width, feel free to change them here as well. Happy Modding.

print("""This file will reset all the .prop files in
creature_editor_palette_pages~, creature_editor_palette_items~ and
creature_editor_palette~ Do you wish to proceed? Y/N""")
verifier = None
while verifier not in ("yes", "y", "no", "n"):
        verifier = input(str(""))
        if verifier.lower() == "y" or verifier.lower() == "yes":
            print("Begin Manual Respawn...")
            a = 0
            b = 40 # This determines how many template pages you want to create, just try to keep the number between 1 and 100
            c = 0
            pagestart = 2827     # 2827 determines the starting point of the page sequence number (this one was picked as its a number no one 
            for i in range(a,b): # would pick), if you have a conflict, set this number to something else, preferably higher than this number (keep in mind the
                pages = open("./creature_editor_palette_pages~/ce_page_icongen_page"+f"{c:02d}"+".prop.prop_t", "w+") # following pages will increment accordingly)
                pages.write(str('''key parent palette_config~!TemplatePalettePartsPage.prop
string16 description "Icon Gen Page '''+str(c+1)+'''"
key paletteCategoryIcon editors_creature~!0x24716B6F.png
float palettePageItemMaxPercentageHeight 0.65
float palettePageItemPercentageWidth 0.65
float palettePageHorizontalOffset 40
int32 palettePageNumRows 1
int32 palettePageNumColumns 1
bool palettePageUseRelativeLayout true
key palettePageParentCategory creature_editor_palette_categories~!ce_category_icongen
uint32 palettePageSequenceNumber '''+str(c+pagestart)+'''
int32 palettePageSetId hash(icongen)'''))  
                pages.close()
                pagesdisp = open("./creature_editor_palette_pages~/ce_page_icongen_page"+f"{c:02d}"+".prop.prop_t", "r")  # Print the file in the console to 
                print("Creature Palette Page No. " + str(c + 1) + "\n" * 2 + pagesdisp.read() + '\n' * 3)                 # look cool.
                pagesdisp.close()
                items = open("./creature_editor_palette_items~/ce_page_icongen_page"+f"{c:02d}"+"_parts.prop.prop_t", "w+")
                items.write(str('''int32s palettePagePartItemColumns
\t0
end
int32s palettePagePartItemRows
\t0
end
keys palettePagePartItems
	creature_rigblock~!
end
key palettePagePartParentPage ce_page_icongen_page'''+str(f"{c:02d}")))
                items.close()
                itemsdisp = open("./creature_editor_palette_items~/ce_page_icongen_page"+f"{c:02d}"+"_parts.prop.prop_t", "r")
                print("Creature Palette Item No. " + str(c + 1) + "\n" * 2 + itemsdisp.read() + '\n' * 3)
                itemsdisp.close()
                if c == b-1:
                    palette = open("./creature_editor_palette~/ce_palette_icongen.prop.prop_t", "w+")
                    palette.write(str("keys palettePalettePages\n"))
                    palette.close()
                    palettelines = open("./creature_editor_palette~/ce_palette_icongen.prop.prop_t", "a")
                    d = 0
                    for j in range(a,b):
                        palettelines.write(str("\t"+"creature_editor_palette_pages~!ce_page_icongen_page"+str(f"{d:02d}")+"\n"))
                        d = d+1
                    palettelines.write(str("end"))
                    palettelines.close()
                    palettedisp = open("./creature_editor_palette~/ce_palette_icongen.prop.prop_t", "r")
                    print("Creature Palette Compiled" + "\n" * 2 + palettedisp.read())
                    palettedisp.close()
                c = c+1
        elif verifier.lower() == "n" or verifier.lower() == "no":
                print("\nDANGER ENTITY UNKNOWN")
                exit()
        else:
            print("Please respond with Y or N / Yes or No")
print("\nDone")
exit()

